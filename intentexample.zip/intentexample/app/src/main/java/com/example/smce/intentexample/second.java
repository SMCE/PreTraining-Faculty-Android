package com.example.smce.intentexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class second extends AppCompatActivity {


    String msg="Welcome to SMCE ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    setContentView(R.layout.activity_second);
        Toast.makeText(getApplicationContext(),
                "Hai Welcome to SMCE", Toast.LENGTH_LONG).show();
       /* Toast mytoast=new Toast(this);
        mytoast.setView(msg);
        mytoast.setDuration(Toast.LENGTH_LONG);
        mytoast.show();*/
       /* msg=getIntent().getExtras().getString("Hai welcome to SMCE");
        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show(); */
    }


}
