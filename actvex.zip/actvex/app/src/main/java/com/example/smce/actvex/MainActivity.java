package com.example.smce.actvex;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView acv;
    String[] values;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        acv =(AutoCompleteTextView)findViewById(R.id.act);
        values=getResources().getStringArray(R.array.val);
        ArrayAdapter<String> adapter=new
                ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,values);
        acv.setThreshold(1);
        acv.setTextColor(Color.BLACK);
        acv.setAdapter(adapter);
    }
}
